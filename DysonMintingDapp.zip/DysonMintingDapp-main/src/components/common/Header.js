import React from "react";
import { MdMenu } from "react-icons/md";
import logo from "../../images/logo.png";
import { FaTwitter, FaDiscord } from "react-icons/fa";

const Header = () => {
  return (
    <nav className="navbar navbar-dark navbar-expand-lg" id="navbar">
      <div className="container-fluid">
        <a className="nav-link" href="#home">
          <img
            src={logo}
            className="img-fluid"
            alt="Logo"
            width="60"
            height="40"
          />
        </a>
        <button
          className="navbar-toggler header-icon"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-label="Toggle navigation"
        >
          <MdMenu className="toggle-btn" />
        </button>
        <div className="navbar-collapse collapse" id="navbarNav">
          <div className="header-end"></div>
          <div className="header-end">
            <div className="icon-group">
              <a
                className="header-icon"
                target="_blank"
                rel="noreferrer"
                href="https://twitter.com/X_periment_X"
              >
                <FaTwitter />
              </a>
              <a
                className="header-icon"
                target="_blank"
                rel="noreferrer"
                href="http://discord.gg/rMqxkvS9Cr"
              >
                <FaDiscord />
              </a>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Header;
