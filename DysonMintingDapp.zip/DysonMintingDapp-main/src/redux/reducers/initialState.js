export default {
  apiCallsInProgress: 0,
};
